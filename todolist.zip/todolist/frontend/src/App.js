import axios from "axios";
import "bootstrap/dist/css/bootstrap.min.css";
import { useEffect, useState } from "react";
import { Button, Container, Form, Table, Alert, Modal } from "react-bootstrap";
import "./App.css";

function App() {
  const [todo, setTodo] = useState("");
  const [task, setTask] = useState("");
  const [updateId, setUpdateId] = useState("");
  const [desc, setDesc] = useState("");
  const [mesg, setMesg] = useState("");
  const [reload, setReload] = useState(true);

  //modals

  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = (id) => {
    setShow(true);
    setUpdateId(id);
  };
  useEffect(() => {
    if (reload) {
      axios
        .get("http://localhost:8000/v1/api/todo")
        .then((res) => {
          setTodo(res.data);
        })
        .then(() => {
          setReload(false);
        })
        .catch((err) => console.log(err));
    }
  }, [reload]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (todo === "" || task === "") {
      setMesg("field cannot be empty");
    } else {
      axios
        .post("http://localhost:8000/v1/api/todo", {
          task,
          desc,
        })
        .then(() => {
          setMesg("");
          setReload(true);
        })
        .catch((err) => console.log(err));
    }
  };

  const handleDelete = (id) => {
    axios.delete(`http://localhost:8000/v1/api/todo/${id}`);
    setReload(true);
  };

  const handleUpdateSubmit = () => {
    if (task.length > 1 && task.length > 1) {
      axios.patch(`http://localhost:8000/v1/api/todo/${updateId}`, {
        task,
        desc,
      });
      setMesg("");
      setReload(true);
    } else {
      setMesg("please set all the fields");
    }
  };
  return (
    <>
      <Container>
        {mesg ? <Alert variant="warning">{mesg}</Alert> : ""}
        <Form className="w-50 my-5 py-5">
          <Form.Group className="mb-3" controlId="Model">
            <Form.Label>Task</Form.Label>
            <Form.Control
              type="text"
              placeholder="Task"
              onChange={(e) => setTask(e.target.value)}
              value={task}
            />
            <Form.Text className="text-muted"></Form.Text>
          </Form.Group>

          <Form.Group className="mb-3" controlId="Description">
            <Form.Label>Description</Form.Label>
            <Form.Control
              type="text"
              placeholder="Description"
              onChange={(e) => setDesc(e.target.value)}
              value={desc}
            />
            <Form.Text className="text-muted"></Form.Text>
          </Form.Group>

          <Button variant="primary" type="submit" onClick={handleSubmit}>
            Submit
          </Button>
        </Form>

        {todo ? (
          <div className="my-5 py-5">
            <Table striped bordered hover>
              <thead>
                <tr>
                  <th>#</th>
                  <th>Task</th>
                  <th>Description</th>
                  <th>update</th>
                  <th>delete</th>
                </tr>
              </thead>
              <tbody>
                {todo.map((item, k) => {
                  return (
                    <tr key={k}>
                      <td>{k}</td>
                      <td>{item.task}</td>
                      <td>{item.desc}</td>
                      <td>
                        <Button
                          variant="success"
                          onClick={() => handleShow(item._id)}
                        >
                          Update
                        </Button>
                      </td>
                      <td>
                        <Button
                          variant="danger"
                          onClick={() => handleDelete(item._id)}
                        >
                          Delete
                        </Button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </Table>
          </div>
        ) : (
          "Loading"
        )}
      </Container>

      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Updating Documents</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {" "}
          <Form className="w-50">
            <Form.Group className="mb-3" controlId="Model">
              <Form.Label>Task</Form.Label>
              <Form.Control
                type="text"
                placeholder="Task"
                onChange={(e) => setTask(e.target.value)}
                value={task}
              />
              <Form.Text className="text-muted"></Form.Text>
            </Form.Group>

            <Form.Group className="mb-3" controlId="Description">
              <Form.Label>Description</Form.Label>
              <Form.Control
                type="text"
                placeholder="Description"
                onChange={(e) => setDesc(e.target.value)}
                value={desc}
              />
              <Form.Text className="text-muted"></Form.Text>
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary" onClick={handleUpdateSubmit}>
            submit
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
}

export default App;
